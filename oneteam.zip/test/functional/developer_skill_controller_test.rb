require 'test_helper'

class DeveloperSkillControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
