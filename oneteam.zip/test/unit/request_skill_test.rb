require 'test_helper'

class RequestSkillTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
