require 'test_helper'

class DeveloperSkillTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
