require 'test_helper'

class CommissionsHelperTest < ActionView::TestCase
end
