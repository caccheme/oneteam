require 'test_helper'

class SkillsHelperTest < ActionView::TestCase
end
