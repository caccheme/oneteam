require 'test_helper'

class DeveloperHelperTest < ActionView::TestCase
end
