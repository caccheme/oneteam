require 'test_helper'

class RequestSkillsHelperTest < ActionView::TestCase
end
