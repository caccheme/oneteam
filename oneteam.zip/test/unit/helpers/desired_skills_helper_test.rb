require 'test_helper'

class DesiredSkillsHelperTest < ActionView::TestCase
end
