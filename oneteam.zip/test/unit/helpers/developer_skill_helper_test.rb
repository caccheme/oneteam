require 'test_helper'

class DeveloperSkillHelperTest < ActionView::TestCase
end
