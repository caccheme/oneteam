require 'test_helper'

class DeveloperSkillsHelperTest < ActionView::TestCase
end
