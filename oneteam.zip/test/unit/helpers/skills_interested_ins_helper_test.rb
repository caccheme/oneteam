require 'test_helper'

class SkillsInterestedInsHelperTest < ActionView::TestCase
end
