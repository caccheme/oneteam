# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OneteamApp::Application.config.secret_token = 'c8ed0262680ec1248bccf7523b858325ddcea9d9c7720ab3c16348c04c217602b248785fec46d054161a44bbf720a1d276ae75236f9091691664b735755d9f67'
